To run the ALU top level test in vivado open './tb' and run 'sim.bat'.
You will need to add vivado to the path.